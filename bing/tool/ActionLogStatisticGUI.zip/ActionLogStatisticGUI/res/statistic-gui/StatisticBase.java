package com.haodou.statistic;

/**
 * 数据统计基本信息常量类
 * Created by qumiao on 2015/10/8.
 */
public class StatisticBase {

    private StatisticBase() {

    }

    /**
     * uuid
     */
    public static final String B_UUID = "a";
    /**
     * 设备型号
     */
    public static final String B_MODEL = "b";
    /**
     * 系统版本
     */
    public static final String B_RELEASE = "c";
    /**
     * app id
     */
    public static final String B_APP_ID = "d";
    /**
     * 版本号
     */
    public static final String B_VERSION_NAME = "e";
    /**
     * MAC地址
     */
    public static final String B_MAC_ADDRESS = "f";
    /**
     * 纬度
     */
    public static final String B_LAT = "g";
    /**
     * 经度
     */
    public static final String B_LNG = "h";
    /**
     * 网络类型
     */
    public static final String B_NET_TYPE = "i";
    /**
     * 屏幕宽度
     */
    public static final String B_SCREEN_WIDTH = "j";
    /**
     * 屏幕高度
     */
    public static final String B_SCREEN_HEIGHT = "k";
    /**
     * 序列号
     */
    public static final String B_SERIAL = "l";
    /**
     * 主板
     */
    public static final String B_BOARD = "m";
    /**
     * bootloader
     */
    public static final String B_BOOTLOADER = "n";
    /**
     * 系统定制商
     */
    public static final String B_BRAND = "o";
    /**
     * 工业设计
     */
    public static final String B_DEVICE = "p";
    /**
     * 硬件名称
     */
    public static final String B_HARDWARE = "q";
    /**
     * 手机制造商
     */
    public static final String B_PRODUCT = "r";
    /**
     * 是否为模拟器
     */
    public static final String B_EMULATOR = "s";
    /**
     * 正版验证
     */
    public static final String B_SIGN_VERIFY = "t";


    /**
     * 统计上传时间
     */
    public static final String B_TIME = "time";
    /**
     * 渠道
     */
    public static final String B_CHANNEL = "channel";
}
