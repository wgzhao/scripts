package com.haodou.statistic;

/**
 * 
 * 数据统计事件常量类
 * 
 * @author lizhiyong <lizhiyong@haodou.com>
 * 
 * $Id$
 *
 */
public class StatisticEvent {
    
    private StatisticEvent() {
        
    }

    /**activity onCreate*/
    public static final String E_ACTIVITY_CREATE = "A1000";
    /**activity onStop*/
    public static final String E_ACTIVITY_STOP = "A1001";
    /**activity onStart*/
    public static final String E_ACTIVITY_START = "A1002";
    /**activity onDestroy*/
    public static final String E_ACTIVITY_DESTROY = "A1003";

    /**手机注册*/
    public static final String E_REG_BY_PHONE = "A1004";
    /**邮箱注册*/
    public static final String E_REG_BY_EMAIL = "A1005";
    /**QQ号绑定注册*/
    public static final String E_REG_BY_QQ = "A1006";
    /**SINA微博账号绑定注册*/
    public static final String E_REG_BY_SINA = "A1007";
    /**登录*/
    public static final String E_LOGIN = "A1008";
    /**QQ账号登录*/
    public static final String E_LOGIN_BY_QQ = "A1009";
    /**SINA 账号登录*/
    public static final String E_LOGIN_BY_SINA = "A1010";
    /**退出登录*/
    public static final String E_LOGOUT = "A1011";
    /**确定退出登录*/
    public static final String E_LOGOUT_SUER = "A1012";
    /**取消退出登录*/
    public static final String E_LOGOUT_CANCEL = "A1013";
    /**点击推送消息*/
    public static final String E_CLICK_PUSH = "A1014";
    /**分享至三分平台*/
    public static final String E_SHARE = "A1015";
    /**push服务器连接状态*/
    public static final String E_PUSH_STATE = "A1016";
    
    public static final String E_LOGIN_BY_WECHAT = "A1017";

    /**统计用户手机上安装的应用列表*/
    public static final String E_UPLOAD_APPINFO = "A3000";
    /**崩溃*/
    public static final String E_CRASH = "A3001";
    /**访问接口http连接失败*/
    public static final String E_HTTP_ERROR = "A3003";
    /**程序无响应*/
    public static final String E_ANR = "A3004";


    /**访问视频菜谱*/
    public static final String E_VISIT_VIDEO_RECIPE = "A4000";
    /**点击播放按钮（大按钮，不是播放/暂停的按钮）*/
    public static final String E_CLICK_VIDEO_PLAY = "A4001";
    /**点击步骤控制视频播放位置*/
    public static final String E_STEP_TO_SEEK = "A4002";
    /**点击视频菜谱上传者的头像*/
    public static final String E_CLICK_VIDEO_USER = "A4003";
    /**视频菜谱播放错误*/
    public static final String E_VIDEO_ERROR = "A4004";
    /**视频菜谱开始（或者恢复）播放*/
    public static final String E_VIDEO_START = "A4005";
    /**视频菜谱结束（或者暂停）播放*/
    public static final String E_VIDEO_STOP = "A4006";

    
    /**分类页面标签的点击情况*/
    public static final String E_CATEGORY = "A5000";
    /** 菜谱详情页评论列表 */
    public static final String E_COMMENT_LIST = "A5001";
    /**我的主页跳转到登录注册模块**/
    public static final String E_LOGIN_TARGET = "A5002";

    /**菜谱下载开始*/
    public static final String E_RECIPE_DOWNLOAD_START = "A6000";
    /**菜谱下载成功*/
    public static final String E_RECIPE_DOWNLOAD_SUCCESS = "A6001";
    /**菜谱下载失败*/
    public static final String E_RECIPE_DOWNLOAD_FAILED = "A6002";
    /**菜谱下载移动*/
    public static final String E_RECIPE_DOWNLOAD_MOVE = "A6003";
    /**菜谱下载删除*/
    public static final String E_RECIPE_DOWNLOAD_DELETE = "A6004";
    /**菜谱下载新分组*/
    public static final String E_RECIPE_DOWNLOAD_GROUP_CREATE = "A6005";
    /**菜谱下载分组重命名*/
    public static final String E_RECIPE_DOWNLOAD_GROUP_RENAME = "A6006";
    /**菜谱下载分组删除*/
    public static final String E_RECIPE_DOWNLOAD_GROUP_DELETE = "A6007";
    /**菜谱下载分组现状*/
    public static final String E_RECIPE_DOWNLOAD_GROUP = "A6008";

    /**普通文件下载失败*/
    public static final String E_DOWNLOAD_FAILED = "A7000";
}
